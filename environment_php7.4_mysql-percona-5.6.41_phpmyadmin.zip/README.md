Docker configuration for Apache, PHP 7.4, MySQL 8 and phpmyadmin.

1. Create sessions folder.
2. Create data/mysq folder.
3. Create logs/mysql folder.
4. Run: docker-compose build
5. Run: docker-compose up


phpmyadmin username / password: root / password
